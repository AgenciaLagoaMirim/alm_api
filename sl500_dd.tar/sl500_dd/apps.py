from django.apps import AppConfig


class Sl500DdConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "sl500_dd"
